<?php
// Conectar ao banco de dados
$servername = "localhost";
$username = "u358426477_lightsabers";
$password = "Customls1!";
$dbname = "u358426477_lightsabers";

// Criar a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Obter o ID do estado
$state_id = $_GET['state_id'];

// Consultar as cidades para o estado dado
$sql = "SELECT id, name FROM city WHERE state_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $state_id);
$stmt->execute();
$result = $stmt->get_result();

$cities = [];
while ($row = $result->fetch_assoc()) {
    $cities[] = $row;
}

$stmt->close();
$conn->close();

// Retornar as cidades em formato JSON
header('Content-Type: application/json');
echo json_encode($cities);
?>